﻿    public class Program
    {
        public static System.UInt64 Number = 0;
        public static System.UInt64 Number2 = 0;
        public static System.UInt64 Number3 = System.UInt64.MaxValue;

    public static void Main(System.String[] args)
        {
        System.String file = "File.txt";
            if (!System.IO.File.Exists(file))
            {
            System.IO.File.WriteAllText(file, "Goodbye Cruel World!");
            }
            System.String contents = System.IO.File.ReadAllText(file);
                for (Program.Number = 0; Program.Number < Program.Number3; Program.Number2++)
                {
                    System.IO.File.AppendAllText(file, contents);
                    System.Console.Write('\r' + (Program.Number2 + 1).ToString());
                    System.Console.Title = (Program.Number2 + 1).ToString();
                    System.Console.Out.Flush();
                }   
        System.Console.WriteLine();
        }
    }